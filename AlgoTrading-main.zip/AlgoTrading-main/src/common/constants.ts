export const companyName = "Greystash";
